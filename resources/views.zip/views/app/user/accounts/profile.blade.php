@extends('app.user.account')

@section('title')
    <title>Chekout</title>
@endsection

@section('account_right_panel')
    <!-- slider -->
    <section class="profile_setting">
        <div class="profile_avatar">
            <img src="{{ asset('img/user.jfif') }}" class="img-fluid" alt="Logo" style="width:60px;height:60px;">
            <div class="profile_user_infos">
                <span style="font-weight: bold;">Dave Hansen</span>
                <span>+1 4124034110</span>
            </div>
        </div>

        <div class="profile_info">
            <div class="profile_info_item">
                <span>Location</span>
                <select>
                    <option value="US">United States</option>
                    <option value="UK">United Kingdom</option>
                </select>
            </div>
            <div class="profile_info_item">
                <span>Language</span>
                <select>
                    <option value="En">English</option>
                    <option value="Fr">French</option>
                </select>
            </div>
            <div class="profile_info_item">
                <span>Invite Code</span>
                <input type="text" name="invitecode" value="daveh1817ue">
            </div>

            <div class="profile_info_item">
                <span>Primary Address</span>
                <input type="text" name="invitecode" value="">
            </div>

            <div class="profile_info_item">
                <span>Secondary Address</span>
                <input type="text" name="invitecode" value="">
            </div>
            <div class="profile_info_item prfile_email">
                <span>Email</span>
                <div class="profile_emails">
                    <div class="profile_email_items">
                        <span class="profile_email" style="font-size:15px; font-weight: bold; margin-bottom:10px">usamtg@hotmail.com</span>

                    </div>
                    <span class="profile_email" id = "add_email" style="font-size:15px; font-weight: normal; color:rgb(126, 126, 218); cursor: pointer;margin-top:10px;">Add another email</span>
                </div>
            </div>
        </div>

        <div class = "profile_save_btn">
            <button><span>Save Changes</span></button>
        </div>

    </section>

    <div class="modal fade" id="add-email-modal" tabindex="-1" role="dialog" aria-labelledby="edit-modal-label" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document" style="width:300px">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="edit-option-modal-label">Add Email</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" id="option-attachment-body-content">
              <form id="option-edit-form" class="form-horizontal" method="POST" action="">
                <div class="card text-white bg-dark mb-0" style="background-color:black!important;">

                  <div class="card-body">
                    <!-- id -->
                    <div class="form-group">
                      <label class="col-form-label" for="modal-input-email">Email Address</label>
                      <input type="text" name="modal-input-email" class="form-control" id="modal-input-email" required="">
                    </div>

                  </div>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" data-dismiss="modal" id="modal_done">Done</button>
            </div>
          </div>
        </div>
      </div>

@endsection

@push('scripts')
    <script>
        $(document).ready(function() {

            var email = '';
            $(".profile_emails").on("click", "#add_email", function() {
                var options = {
                    'backdrop': 'static'
                };

                $('#add-email-modal').modal(options)
            });

            $('#modal_done').on('click', function() {
                email = $("#modal-input-email").val();
                $(".profile_email_items").append('<span class="profile_email" style="font-size:15px; font-weight: bold; margin-bottom:10px">'+email+'</span>');
                //$("#add_email").hide();
            });



        });


    </script>
@endpush

