@extends('layouts.app')

@section('title')
    <title>Chekout</title>
@endsection

@section('content')
    <!-- slider -->

<section class="account_content">
    <section class="account_left">
        <ul>
            <li>
                <a><span>Request a ride</span></a>
            </li>
            <li>
                <a><span>My tips</span></a>
            </li>
            <li>
                <a><span>Wallet</span></a>
            </li>
            <li>
                <a><span>Free rides</span></a>
            </li>
            <li class="nav_selected">
                <a><span>Profile Settings</span></a>
            </li>
        </ul>
    </section>
    <section class="account_right">
        @yield('account_right_panel')
    </section>
</section>

@endsection

@push('scripts')
    <script>

    </script>
@endpush

