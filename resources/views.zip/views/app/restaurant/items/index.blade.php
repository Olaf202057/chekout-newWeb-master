@extends('app.user.account')

@section('title')
    <title>Chekout</title>
@endsection

@section('content')
    <!-- slider -->


@endsection

@push('scripts')
    <script>
        $(document).ready(function() {


        });


    </script>
@endpush

