@extends('layouts.app')

@section('title')
    <title>Chekout</title>
@endsection
@section('content')
    <div class="page-banner p-relative smoothscroll" id="menu">
        <img src="{{$restaurant->logo_url ?? asset('img/slider.jpeg')}}" class="img-fluid full-width"
             alt="banner">
        <div class="overlay-2">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <div class="back-btn">
                            <button type="button" class="text-light-green"><i class="fas fa-chevron-left"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="tag-share"><span class="text-light-green share-tag">
                                <i class="fas fa-chevron-right"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- restaurent top -->
    <!-- restaurent details -->
    <section class="restaurent-details  u-line">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="heading padding-tb-10">
                        <h3 class="text-light-black title fw-700 no-margin">{{ $restaurant->name ?? 'Untitled' }}</h3>
                        <p class="text-light-black sub-title no-margin">{{ $restaurant->location->address1 ?? 'Unlisted Address' }}
                            {{--                            <span><a href="checkout.html" class="text-success">Change locations</a></span>--}}
                        </p>
                        {{--                        <div class="head-rating">--}}
                        {{--                            --}}{{--                             Todo: Need to make this work wth an actual rating reviewsSum/reviewsCount--}}
                        {{--                            <div class="rating"> <span class="fs-16 text-yellow">--}}
                        {{--                              <i class="fas fa-star"></i>--}}
                        {{--                            </span>--}}
                        {{--                                <span class="fs-16 text-yellow">--}}
                        {{--                              <i class="fas fa-star"></i>--}}
                        {{--                            </span>--}}
                        {{--                                <span class="fs-16 text-yellow">--}}
                        {{--                              <i class="fas fa-star"></i>--}}
                        {{--                            </span>--}}
                        {{--                                <span class="fs-16 text-yellow">--}}
                        {{--                              <i class="fas fa-star"></i>--}}
                        {{--                            </span>--}}
                        {{--                                <span class="fs-16 text-dark-white">--}}
                        {{--                              <i class="fas fa-star"></i>--}}
                        {{--                            </span>--}}
                        {{--                                <span class="text-light-black fs-12 rate-data">--}}
                        {{--                                    {{ $restaurant->reviewsCount ?? 0}}--}}
                        {{--                                    {{ isset($restaurant->reviewsCount) && ($restaurant->reviewsCount != 1) ? 'ratings' : 'rating' }}--}}
                        {{--                                </span>--}}
                        {{--                            </div>--}}
                        {{--                            <div class="product-review">--}}
                        {{--                                <div class="restaurent-details-mob">--}}
                        {{--                                    <a href="#"> <span class="text-light-black"><i--}}
                        {{--                                                class="fas fa-info-circle"></i></span>--}}
                        {{--                                        <span class="text-dark-white">info</span>--}}
                        {{--                                    </a>--}}
                        {{--                                </div>--}}
                        {{--                                <div class="restaurent-details-mob">--}}
                        {{--                                    <a href="#"> <span class="text-light-black"><i--}}
                        {{--                                                class="fas fa-info-circle"></i></span>--}}
                        {{--                                        <span class="text-dark-white">info</span>--}}
                        {{--                                    </a>--}}
                        {{--                                </div>--}}
                        {{--                                <div class="restaurent-details-mob">--}}
                        {{--                                    <a href="#"> <span class="text-light-black"><i--}}
                        {{--                                                class="fas fa-info-circle"></i></span>--}}
                        {{--                                        <span class="text-dark-white">info</span>--}}
                        {{--                                    </a>--}}
                        {{--                                </div>--}}
                        {{--                                <div class="restaurent-details-mob">--}}
                        {{--                                    <a href="#"> <span class="text-light-black"><i--}}
                        {{--                                                class="fas fa-info-circle"></i></span>--}}
                        {{--                                        <span class="text-dark-white">info</span>--}}
                        {{--                                    </a>--}}
                        {{--                                </div>--}}
                        {{--                                --}}{{--                                <h6 class="text-light-black no-margin">91<span class="fs-14">% Food was good</span></h6>--}}
                        {{--                                --}}{{--                                <h6 class="text-light-black no-margin">91<span class="fs-14">% Food was good</span></h6>--}}
                        {{--                                --}}{{--                                <h6 class="text-light-black no-margin">91<span class="fs-14">% Food was good</span></h6>--}}
                        {{--                            </div>--}}
                        {{--                        </div>--}}
                    </div>
                    <div class="restaurent-logo">
                        <img src="{{ $restaurant->logo_url ?? asset('img/logo.png') }}" class="img-fluid" alt="#">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- restaurent details -->
    <!-- restaurent tab -->
    <div class="restaurent-tabs u-line">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="restaurent-menu scrollnav">
                        <ul class="nav nav-pills">
                            <li class="nav-item"><a class="nav-link active text-light-white fw-700" data-toggle="pill"
                                                    href="#menu">Menu</a>
                            </li>
                            <li class="nav-item"><a class="nav-link text-light-white fw-700" data-toggle="pill"
                                                    href="#about">About</a>
                            </li>
                            <li class="nav-item"><a class="nav-link text-light-white fw-700" data-toggle="pill"
                                                    href="#review">Reviews</a>
                            </li>
                            <li class="nav-item"><a class="nav-link text-light-white fw-700" data-toggle="pill"
                                                    href="#mapgallery">Map & Gallery</a>
                            </li>
                        </ul>
                        <div class="add-wishlist">
                            <img src="/img/svg/013-heart-1.svg" alt="tag">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- restaurent tab -->
    <!-- restaurent address -->
    <div class="restaurent-address u-line">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="address-details">
                        <div class="address">
                            <div class="delivery-address"><a href="" class="text-light-black">Delivery,
                                    ASAP
                                    ({{ isset($restaurant->prep_minutes) ? $restaurant->prep_minutes . ' minutes' : 'No Estimate Available' }}
                                    )</a>
                                <div class="delivery-type"><span
                                        class="text-success fs-12 fw-500">No minimum</span>
                                    {{--                                    <span class="text-light-white">, Free Delivery</span>--}}
                                </div>
                            </div>
                            {{--                            <div class="change-address"><a href="checkout.html" class="fw-500">Change</a>--}}
                            {{--                            </div>--}}
                        </div>
                        {{--                        <p class="text-light-white no-margin">Lorem ipsum dolor sit amet, consectetur adipiscing--}}
                        {{--                            elit,</p>--}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- restaurent address -->
    <!-- restaurent meals -->
    <section class="section-padding restaurent-meals bg-light-theme">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-3">
                    {{--                    <div class="advertisement-slider swiper-container h-auto mb-xl-20 mb-md-40">--}}
                    {{--                        <div class="swiper-wrapper">--}}
                    {{--                            <div class="swiper-slide">--}}
                    {{--                                <div class="testimonial-wrapper">--}}
                    {{--                                    <div class="testimonial-box">--}}
                    {{--                                        <div class="testimonial-img p-relative">--}}
                    {{--                                            <a href="restaurant.html">--}}
                    {{--                                                <img src="https://via.placeholder.com/438x180"--}}
                    {{--                                                     class="img-fluid full-width" alt="testimonial-img">--}}
                    {{--                                            </a>--}}
                    {{--                                            <div class="overlay">--}}
                    {{--                                                <div class="brand-logo">--}}
                    {{--                                                    <img src="https://via.placeholder.com/50" class="img-fluid"--}}
                    {{--                                                         alt="logo">--}}
                    {{--                                                </div>--}}
                    {{--                                                <div class="add-fav text-success">--}}
                    {{--                                                    <img src="/img/svg/013-heart-1.svg" alt="tag">--}}
                    {{--                                                </div>--}}
                    {{--                                            </div>--}}
                    {{--                                        </div>--}}
                    {{--                                        <div class="testimonial-caption padding-15">--}}
                    {{--                                            <p class="text-light-white text-uppercase no-margin fs-12">Featured</p>--}}
                    {{--                                            <h5 class="fw-600"><a href="restaurant.html" class="text-light-black">GSA--}}
                    {{--                                                    King Tomato Farm</a></h5>--}}
                    {{--                                            <div class="testimonial-user-box">--}}
                    {{--                                                <img src="https://via.placeholder.com/40" class="rounded-circle"--}}
                    {{--                                                     alt="#">--}}
                    {{--                                                <div class="testimonial-user-name">--}}
                    {{--                                                    <p class="text-light-black fw-600">Sarra</p> <i--}}
                    {{--                                                        class="fas fa-trophy text-black"></i><span--}}
                    {{--                                                        class="text-light-black">Top Reviewer</span>--}}
                    {{--                                                </div>--}}
                    {{--                                            </div>--}}
                    {{--                                            <div class="ratings"> <span class="text-yellow fs-16">--}}
                    {{--                                                          <i class="fas fa-star"></i>--}}
                    {{--                                                        </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                          <i class="fas fa-star"></i>--}}
                    {{--                                                        </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                          <i class="fas fa-star"></i>--}}
                    {{--                                                        </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                          <i class="fas fa-star"></i>--}}
                    {{--                                                        </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                          <i class="fas fa-star"></i>--}}
                    {{--                                                        </span>--}}
                    {{--                                            </div>--}}
                    {{--                                            <p class="text-light-black">Delivery was fast and friendly...</p>--}}
                    {{--                                            <p class="text-light-white fw-100"><strong class="text-light-black fw-700">Local--}}
                    {{--                                                    delivery: </strong> From $7.99 (4.0 mi)</p>--}}
                    {{--                                            <a href="checkout.html" class="btn-second btn-submit">Order Now</a>--}}
                    {{--                                        </div>--}}
                    {{--                                    </div>--}}
                    {{--                                </div>--}}
                    {{--                            </div>--}}
                    {{--                            <div class="swiper-slide">--}}
                    {{--                                <div class="testimonial-wrapper">--}}
                    {{--                                    <div class="testimonial-box">--}}
                    {{--                                        <div class="testimonial-img p-relative">--}}
                    {{--                                            <a href="restaurant.html">--}}
                    {{--                                                <img src="https://via.placeholder.com/438x180"--}}
                    {{--                                                     class="img-fluid full-width" alt="testimonial-img">--}}
                    {{--                                            </a>--}}
                    {{--                                            <div class="overlay">--}}
                    {{--                                                <div class="brand-logo">--}}
                    {{--                                                    <img src="https://via.placeholder.com/50" class="img-fluid"--}}
                    {{--                                                         alt="logo">--}}
                    {{--                                                </div>--}}
                    {{--                                                <div class="add-fav text-success"><img src="/img/svg/013-heart-1.svg"--}}
                    {{--                                                                                       alt="tag">--}}
                    {{--                                                </div>--}}
                    {{--                                            </div>--}}
                    {{--                                        </div>--}}
                    {{--                                        <div class="testimonial-caption padding-15">--}}
                    {{--                                            <p class="text-light-white text-uppercase no-margin fs-12">Featured</p>--}}
                    {{--                                            <h5 class="fw-600"><a href="restaurant.html" class="text-light-black">GSA--}}
                    {{--                                                    King Tomato Farm</a></h5>--}}
                    {{--                                            <div class="testimonial-user-box">--}}
                    {{--                                                <img src="https://via.placeholder.com/40" class="rounded-circle"--}}
                    {{--                                                     alt="#">--}}
                    {{--                                                <div class="testimonial-user-name">--}}
                    {{--                                                    <p class="text-light-black fw-600">Sarra</p> <i--}}
                    {{--                                                        class="fas fa-trophy text-black"></i><span--}}
                    {{--                                                        class="text-light-black">Top Reviewer</span>--}}
                    {{--                                                </div>--}}
                    {{--                                            </div>--}}
                    {{--                                            <div class="ratings"> <span class="text-yellow fs-16">--}}
                    {{--                                                  <i class="fas fa-star"></i>--}}
                    {{--                                                </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                  <i class="fas fa-star"></i>--}}
                    {{--                                                </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                  <i class="fas fa-star"></i>--}}
                    {{--                                                </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                  <i class="fas fa-star"></i>--}}
                    {{--                                                </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                                  <i class="fas fa-star"></i>--}}
                    {{--                                                </span>--}}
                    {{--                                            </div>--}}
                    {{--                                            <p class="text-light-black">Delivery was fast and friendly...</p>--}}
                    {{--                                            <p class="text-light-white fw-100"><strong class="text-light-black fw-700">Local--}}
                    {{--                                                    delivery: </strong> From $7.99 (4.0 mi)</p>--}}
                    {{--                                            <a href="checkout.html" class="btn-second btn-submit">Order Now</a>--}}
                    {{--                                        </div>--}}
                    {{--                                    </div>--}}
                    {{--                                </div>--}}
                    {{--                            </div>--}}
                    {{--                            <div class="swiper-slide">--}}
                    {{--                                <div class="testimonial-wrapper">--}}
                    {{--                                    <div class="testimonial-box">--}}
                    {{--                                        <div class="testimonial-img p-relative">--}}
                    {{--                                            <a href="restaurant.html">--}}
                    {{--                                                <img src="https://via.placeholder.com/438x180"--}}
                    {{--                                                     class="img-fluid full-width" alt="testimonial-img">--}}
                    {{--                                            </a>--}}
                    {{--                                            <div class="overlay">--}}
                    {{--                                                <div class="brand-logo">--}}
                    {{--                                                    <img src="https://via.placeholder.com/50" class="img-fluid"--}}
                    {{--                                                         alt="logo">--}}
                    {{--                                                </div>--}}
                    {{--                                                <div class="add-fav text-success"><img src="/img/svg/013-heart-1.svg"--}}
                    {{--                                                                                       alt="tag">--}}
                    {{--                                                </div>--}}
                    {{--                                            </div>--}}
                    {{--                                        </div>--}}
                    {{--                                        <div class="testimonial-caption padding-15">--}}
                    {{--                                            <p class="text-light-white text-uppercase no-margin fs-12">Featured</p>--}}
                    {{--                                            <h5 class="fw-600"><a href="restaurant.html" class="text-light-black">GSA--}}
                    {{--                                                    King Tomato Farm</a></h5>--}}
                    {{--                                            <div class="testimonial-user-box">--}}
                    {{--                                                <img src="https://via.placeholder.com/40" class="rounded-circle"--}}
                    {{--                                                     alt="#">--}}
                    {{--                                                <div class="testimonial-user-name">--}}
                    {{--                                                    <p class="text-light-black fw-600">Sarra</p> <i--}}
                    {{--                                                        class="fas fa-trophy text-black"></i><span--}}
                    {{--                                                        class="text-light-black">Top Reviewer</span>--}}
                    {{--                                                </div>--}}
                    {{--                                            </div>--}}
                    {{--                                            <div class="ratings"> <span class="text-yellow fs-16">--}}
                    {{--                                              <i class="fas fa-star"></i>--}}
                    {{--                                            </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                              <i class="fas fa-star"></i>--}}
                    {{--                                            </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                              <i class="fas fa-star"></i>--}}
                    {{--                                            </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                              <i class="fas fa-star"></i>--}}
                    {{--                                            </span>--}}
                    {{--                                                <span class="text-yellow fs-16">--}}
                    {{--                                              <i class="fas fa-star"></i>--}}
                    {{--                                            </span>--}}
                    {{--                                            </div>--}}
                    {{--                                            <p class="text-light-black">Delivery was fast and friendly...</p>--}}
                    {{--                                            <p class="text-light-white fw-100"><strong class="text-light-black fw-700">Local--}}
                    {{--                                                    delivery: </strong> From $7.99 (4.0 mi)</p>--}}
                    {{--                                            <a href="checkout.html" class="btn-second btn-submit">Order Now</a>--}}
                    {{--                                        </div>--}}
                    {{--                                    </div>--}}
                    {{--                                </div>--}}
                    {{--                            </div>--}}
                    {{--                        </div>--}}
                    {{--                        <!-- Add Arrows -->--}}
                    {{--                        <div class="swiper-button-next"></div>--}}
                    {{--                        <div class="swiper-button-prev"></div>--}}
                    {{--                    </div>--}}
                    {{--                    <div class="card sidebar-card">--}}
                    {{--                        <div class="card-header no-padding">--}}
                    {{--                            <div class="offer-content">--}}
                    {{--                                <h2 class="text-custom-white fw-700">Get $12 off <small class=" fw-700">your--}}
                    {{--                                        order*</small></h2>--}}
                    {{--                                <p class="text-custom-white">As an added treat, enjoy <strong>free delivery</strong>--}}
                    {{--                                    from--}}
                    {{--                                    <br>select restaurants automatically applied at checkout</p>--}}
                    {{--                            </div>--}}
                    {{--                        </div>--}}
                    {{--                        <div class="card-body padding-15">--}}
                    {{--                            <form>--}}
                    {{--                                <div class="row">--}}
                    {{--                                    <div class="col-12">--}}
                    {{--                                        <div class="form-group">--}}
                    {{--                                            <label class="text-light-white fs-14">Email</label>--}}
                    {{--                                            <input type="email" name="#" class="form-control form-control-submit"--}}
                    {{--                                                   placeholder="Email I'd">--}}
                    {{--                                        </div>--}}
                    {{--                                        <div class="form-group">--}}
                    {{--                                            <label class="text-light-white fs-14">ZIP Code</label>--}}
                    {{--                                            <input type="number" name="#" class="form-control form-control-submit"--}}
                    {{--                                                   placeholder="10421">--}}
                    {{--                                        </div>--}}
                    {{--                                        <div class="form-group">--}}
                    {{--                                            <button type="submit" class="btn-second btn-submit full-width">Save $12 on--}}
                    {{--                                                your first order--}}
                    {{--                                            </button>--}}
                    {{--                                        </div>--}}

                    {{--                                        <div class="text-center"> <span class="text-light-black fs-12">*Valid on first order only, for one-time use, subject to foodmart’s verification. Additional terms may apply. By signing up, you agree to receive marketing and--}}
                    {{--                        promotional emails and communications form foodmart</span>--}}
                    {{--                                        </div>--}}
                    {{--                                    </div>--}}
                    {{--                                </div>--}}
                    {{--                            </form>--}}
                    {{--                        </div>--}}
                    {{--                    </div>--}}
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="row">
                        <div class="col-12">
                            <div class="alert alert-info text-center" id="alert" style="display: none;">

                            </div>
                        </div>
                        {{--                        <div class="col-lg-12">--}}
                        {{--                            <div class="promocodeimg mb-xl-20 p-relative">--}}
                        {{--                                <img src="https://via.placeholder.com/1100x115" class="img-fluid full-width"--}}
                        {{--                                     alt="promocode">--}}
                        {{--                                <div class="promocode-text">--}}
                        {{--                                    <div class="promocode-text-content">--}}
                        {{--                                        <h5 class="text-custom-white mb-2 fw-600">Get $10 off your first order!</h5>--}}
                        {{--                                        <p class="text-custom-white no-margin">Spend $15 or more and get $10 off your--}}
                        {{--                                            first delivery order.</p>--}}
                        {{--                                    </div>--}}
                        {{--                                    <div class="promocode-btn"><a href="#">Get Deal</a>--}}
                        {{--                                    </div>--}}
                        {{--                                </div>--}}
                        {{--                                <div class="overlay overlay-bg"></div>--}}
                        {{--                            </div>--}}
                        {{--                        </div>--}}
                        @php
                            $inc = 0;
                        @endphp
                        @foreach($menus as $menu)
                            <div class="col-lg-12 restaurent-meal-head">
                                <div class="card">
                                    <div class="card-header p-2">
                                        <div class="section-header-left">
                                            <h3 class="text-light-black header-title">
                                                <a class="card-link text-light-black no-margin {{ $inc == 0 ? '' : 'collapsed'  }}"
                                                   data-toggle="collapse"
                                                   href="#collapse{{$menu['id']}}">
                                                    {{ $menu['name'] }}
                                                </a>
                                            </h3>
                                        </div>
                                    </div>
                                    <div id="collapse{{$menu['id']}}" class="collapse {{ $inc == 0 ? 'show' : ''  }}">
                                        @php
                                            $inc ++;
                                        @endphp
                                        <div class="card-body no-padding">
                                            <div class="row">
                                                @foreach($menu['sections'] as $section)
                                                    <div class="col-lg-12 restaurent-meal-head">
                                                        <div class="card ml-4 mr-2">
                                                            <div class="card-header">
                                                                <div class="section-header-left pb-0">
                                                                    <h3 class="text-light-black">
                                                                        <a class="card-link text-light-black no-margin collapsed"
                                                                           data-toggle="collapse"
                                                                           href="#collapse{{$section['id']}}"
                                                                           style="font-size: .6em !important;">
                                                                            {{ $section['name'] }}
                                                                        </a>
                                                                    </h3>
                                                                </div>
                                                            </div>
                                                            <div class="card-body no-padding">
                                                                <div id="collapse{{$section['id']}}" class="collapse">
                                                                    <div class="card-body no-padding">
                                                                        <div class="row">
                                                                            @if(count($section['items']) > 0)
                                                                                @foreach($section['items'] as $product)
                                                                                    <x-menu-item-card
                                                                                        :product="$product"
                                                                                        :restaurant="$restaurant"></x-menu-item-card>
                                                                                @endforeach
                                                                            @else
                                                                                <div class="col-12">
                                                                                    <div class="alert alert-info">
                                                                                        This restaurant doesn't have a
                                                                                        menu
                                                                                        set up yet.
                                                                                    </div>
                                                                                </div>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3">
                    <div class="sidebar">
                        <x-restaurant-cart-card :cart="$cart" :restaurant="$restaurant"></x-restaurant-cart-card>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- restaurent meals -->
    <!-- restaurent about -->
    <section class="section-padding restaurent-about smoothscroll" id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="text-light-black fw-700 title">{{ $restaurant->title ?? '' }}</h3>
                    {{--                    <p class="text-light-green no-margin">American, Breakfast, Coffee and Tea, Fast Food, Hamburgers</p>--}}
                    <p class="text-light-white no-margin">{{ $restaurant->description ?? '' }}</p>
                    <span
                        class="text-{{ isset($restaurant->price) && $restaurant->price > 0 ? 'success' : 'dark-white' }} fs-16">$</span>
                    <span
                        class="text-{{ isset($restaurant->price) && $restaurant->price > 1 ? 'success' : 'dark-white' }} fs-16">$</span>
                    <span
                        class="text-{{ isset($restaurant->price) && $restaurant->price > 2 ? 'success' : 'dark-white' }} fs-16">$</span>
                    <span
                        class="text-{{ isset($restaurant->price) && $restaurant->price > 3 ? 'success' : 'dark-white' }} fs-16">$</span>
                    <span
                        class="text-{{ isset($restaurant->price) && $restaurant->price > 4 ? 'success' : 'dark-white' }} fs-16">$</span>
                    <ul class="about-restaurent">
                        <li>
                            <i class="fas fa-building"></i>
                            <span>
                                <a href="#" class="text-light-white">{{ $restaurant->name }}</a>
                            </span>
                        </li>
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <span>
                                <a href="#" class="text-light-white">{{ $restaurant->location->address1 }}</a>
                            </span>
                        </li>
                        <li><i class="fas fa-phone-alt"></i>
                            <span><a href="tel:"
                                     class="text-light-white">{{isset($restaurant->contact) && isset($restaurant->contact->phone) ? $restaurant->contact->phone : 'Unlisted'}}</a></span>
                        </li>
                        {{--                        <li><i class="far fa-envelope"></i>--}}
                        {{--                            <span><a href="mailto:" class="text-light-white">demo@domain.com</a></span>--}}
                        {{--                        </li>--}}
                    </ul>
                    {{--                    <ul class="social-media pt-2">--}}
                    {{--                        <li><a href="#"><i class="fab fa-facebook-f"></i></a>--}}
                    {{--                        </li>--}}
                    {{--                        <li><a href="#"><i class="fab fa-twitter"></i></a>--}}
                    {{--                        </li>--}}
                    {{--                        <li><a href="#"><i class="fab fa-instagram"></i></a>--}}
                    {{--                        </li>--}}
                    {{--                        <li><a href="#"><i class="fab fa-pinterest-p"></i></a>--}}
                    {{--                        </li>--}}
                    {{--                        <li><a href="#"><i class="fab fa-youtube"></i></a>--}}
                    {{--                        </li>--}}
                    {{--                    </ul>--}}
                </div>
                <div class="col-md-6">
                    <div class="restaurent-schdule">
                        <div class="card">
                            <div class="card-header text-light-white fw-700 fs-16">Hours</div>
                            <div class="card-body">
                                <div class="schedule-box">
                                    @if(isset($restaurant->operation_info) && isset($restaurant->operation_info) && count($restaurant->operation_info->monday) > 0)
                                        <div class="day text-light-black">Monday</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    @endif
                                </div>
                                <div class="collapse show" id="schdule">
                                    <div class="schedule-box">
                                        <div class="day text-light-black">Tuesday</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    </div>
                                    <div class="schedule-box">
                                        <div class="day text-light-black">Wednesday</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    </div>
                                    <div class="schedule-box">
                                        <div class="day text-light-black">Thurdsay</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    </div>
                                    <div class="schedule-box">
                                        <div class="day text-light-black">Friday</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    </div>
                                    <div class="schedule-box">
                                        <div class="day text-light-black">Saturday</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    </div>
                                    <div class="schedule-box">
                                        <div class="day text-light-black">Sunday</div>
                                        <div
                                            class="time text-light-black">{{ $restaurant->operation_info->monday[0] == true ? $restaurant->operation_info->monday[1] . ' - ' . $restaurant->operation_info->monday[2] : 'Closed' }}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer"><a class="fw-500" data-toggle="collapse" href="#schdule">See
                                    the full schedule</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- restaurent about -->
    <!-- map gallery -->
    <div class="map-gallery-sec section-padding bg-light-theme smoothscroll" id="mapgallery">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main-box">
                        <div class="row">
                            <div class="col-md-6 map-pr-0">
                                <iframe id="locmap"
                                        src="https://maps.google.com/maps?q={{ $restaurant->location->address1 }}&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
                            </div>
                            <div class="col-md-6 map-pl-0">
                                <div class="gallery-box padding-10">
                                    <ul class="gallery-img">
                                        <li>
                                            <a class="image-popup"
                                               href="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                               title="Image title">
                                                <img
                                                    src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                                    class="img-fluid full-width"
                                                    alt="9.jpg"/>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="image-popup"
                                               href="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                               title="Image title">
                                                <img
                                                    src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                                    class="img-fluid full-width"
                                                    alt="9.jpg"/>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="image-popup"
                                               href="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                               title="Image title">
                                                <img
                                                    src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                                    class="img-fluid full-width"
                                                    alt="9.jpg"/>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="image-popup"
                                               href="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                               title="Image title">
                                                <img
                                                    src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                                    class="img-fluid full-width"
                                                    alt="9.jpg"/>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="image-popup"
                                               href="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                               title="Image title">
                                                <img
                                                    src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                                    class="img-fluid full-width"
                                                    alt="9.jpg"/>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="image-popup"
                                               href="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                               title="Image title">
                                                <img
                                                    src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
                                                    class="img-fluid full-width"
                                                    alt="9.jpg"/>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- map gallery -->
    <!-- restaurent reviews -->
    @php
        $reviewTotal = isset($restaurant->reviewsCount) && $restaurant->reviewsCount > 0 && $restaurant->reviewsSum > 0 ? $restaurant->reviewsSum / $restaurant->reviewsCount : 0;
    @endphp
    <section class="section-padding restaurent-review smoothscroll" id="review">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-header-left">
                        <h3 class="text-light-black header-title title">Reviews
                            for {{ $restaurant->title ?? 'this restaurant' }}</h3>
                    </div>
                    <div class="restaurent-rating mb-xl-20">
                        <div class="star"><span class="text-{{ $reviewTotal > 0 ? 'yellow' : 'dark-white'}} fs-16">
                                <i class="fas fa-star"></i>
                            </span>
                            <span class="text-{{ $reviewTotal > 1 ? 'yellow' : 'dark-white'}} fs-16">
                                <i class="fas fa-star"></i>
                            </span>
                            <span class="text-{{ $reviewTotal > 2 ? 'yellow' : 'dark-white'}} fs-16">
                                <i class="fas fa-star"></i>
                            </span>
                            <span class="text-{{ $reviewTotal > 3 ? 'yellow' : 'dark-white'}} fs-16">
                                <i class="fas fa-star"></i>
                            </span>
                            <span class="text-{{ $reviewTotal > 4 ? 'yellow' : 'dark-white'}} fs-16">
                                <i class="fas fa-star"></i>
                            </span>
                        </div>
                        <span class="fs-12 text-light-black">
                            {{ $restaurant->reviewsCount ?? 0}}
                            {{ isset($restaurant->reviewsCount) && ($restaurant->reviewsCount != 1) ? 'ratings' : 'rating' }}</span>
                    </div>
                    <div class="u-line"></div>
                </div>
                @if(isset($reviews) && $reviews->count() > 0)
                    <div class="col-md-12">
                        @foreach($reviews as $review)
                            <div class="review-box">
                                <div class="review-user">
                                    <div class="review-user-img">
                                        <img src="{{ $review['authorProfilePic'] ?? 'https://via.placeholder.com/40' }}"
                                             class="rounded-circle" alt="#" style="max-height: 90px;">
                                        <div class="reviewer-name">
                                            <p class="text-light-black fw-600">{{ $review['authorName'] && trim($review['authorName']) != '' ? $review['authorName'] : 'Anonymous' }}
                                            {{--                                                <small class="text-light-white fw-500">New--}}
                                            {{--                                                    York, (NY)</small>--}}
                                            {{--                                            </p> <i class="fas fa-trophy text-black"></i><span class="text-light-black">Top Reviewer</span>--}}
                                        </div>
                                    </div>
                                    <div class="review-date"><span class="text-light-white">Sep 20, 2020</span>
                                    </div>
                                </div>
                                <div class="ratings"><span
                                        class="text-{{ $review['rating'] > 0 ? 'yellow' : 'dark-white' }} fs-16">
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span class="text-{{ $review['rating'] > 1 ? 'yellow' : 'dark-white' }} fs-16">
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span class="text-{{ $review['rating'] > 2 ? 'yellow' : 'dark-white' }} fs-16">
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span class="text-{{ $review['rating'] > 3 ? 'yellow' : 'dark-white' }} fs-16">
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span class="text-{{ $review['rating'] > 4 ? 'yellow' : 'dark-white' }} fs-16">
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span class="ml-2 text-light-white">2 days ago</span>
                                </div>
                                <p class="text-light-black">{{ isset($review['text']) && trim($review['text']) != '' ? $review['text'] :  'No text provided.'}}</p>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="col-12">
                        <div class="review-img">
                            <img src="/img/review-footer.png" class="img-fluid" alt="#">
                            <div class="review-text">
                                <h2 class="text-light-white mb-2 fw-600">Be one of the first to review</h2>
                                <p class="text-light-white">Order now and write a review to give others the inside
                                    scoop.</p>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </section>
@endsection

@push('scripts')
    <script>
        $(document).ready(function () {
            $(document).on('submit', '.add-to-cart-form', function (e) {
                e.preventDefault();
                var form = $(e.target);
                console.log(form.attr('action'));
                var inputs = form.find('input');
                var select = form.find('select');

                // not sure if you wanted this, but I thought I'd add it.
                // get an associative array of just the values.
                var values = {};
                inputs.each(function () {
                    values[this.name] = $(this).val();
                });
                select.each(function () {
                    values[this.name] = $(this).val();
                });
                console.log(values);
                $.post(form.attr('action'), values, "json"
                )
                    .done(function (data) {
                        console.log(data);
                        if (data.error) {
                            $('#alert').show();
                            $('#alert').empty().append(
                                '<div class="row">' + data.error + '</div>' +
                                '<div class="row">' + data.alert + '</div>'
                            );
                        } else {
                            // Todo: Prepend to not get rid of the subtotal box.
                            var cartItems = $(document).find('.cat-product-box').remove();
                            var cartBadge = $(document).find('.user-alert-cart').first();
                            console.log('Cart Badge Below');
                            console.log(cartBadge);
                            cartBadge.empty().text(data.items.length);
                            var carts = $(document).find('.cart-item-holder');
                            console.log(carts);
                            carts.each(function () {
                                var items = data.items;
                                var string = '';
                                for (var itemkey in items) {
                                    string += parseFirstCartItemString(items[itemkey], itemkey) + parseSecondCartItemString(items[itemkey], itemkey) + parseThirdCartItemString(items[itemkey], itemkey);
                                }
                                $(this).html(string);
                            });

                            var subtotals = $(document).find('.cart-subtotal');
                            subtotals.each(function (subtotalEvent) {
                                $(this).empty().append(
                                    '<a href="#" class="text-dark-white fw-500">$' + data.subtotal + '</a>');
                            });
                        }
                    })
            });

            function parseFirstCartItemString(item, index) {
                console.log(item);
                return '<div class="cat-product-box" data-cart="' + index + '-' + item.id + '">' +
                '                        <div class="cat-product">' +
                '                            <div class="cat-name">' +
                '                                <div class="row">' +
                '                                    <div class="col-12">' +
                '                                        <a href="#">' +
                '                                            <p class="text-dark"><span' +
               '                                                    class="text-dark-white">' + item.quantity + '</span>' + item.name + '</p>';
            }

            function parseSecondCartItemString(item, index) {
                var string = '';
                options = item.options;
                for (var optionkey in options) {
                    string += '<span class="text-light-white">' + options[optionkey] + '</span>';
                }
                return string;
            }

            function parseThirdCartItemString(item, index) {
                return '                                            <div class="delete-btn">' +
                    '                                                <a class="text-dark-white remove-item"' +
                    '                                                   data-id="' + item.id + '" data-index="' + index + '"> <i' +
                    '                                                        class="far fa-trash-alt"></i>' +
                    '                                                </a>' +
                    '                                            </div>' +
                    '                                        </a>' +
                    '                                    </div>' +
                    '                                </div>' +
                    '                            </div>' +
                    '                            <div class="price"><a href="#" class="text-dark-white fw-500">' +
                    '$' + item.price +
                    '                                </a>' +
                    '                            </div>' +
                    '                        </div>' +
                    '                    </div>';
            }
        });
    </script>
@endpush

