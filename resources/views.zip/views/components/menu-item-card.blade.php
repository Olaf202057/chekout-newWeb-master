<div class="col-lg-12">
    <div class="restaurent-product-list">
        <div class="restaurent-product-detail">
            <div class="restaurent-product-left">
                <div class="restaurent-product-title-box">
                    <div class="restaurent-product-box">
                        <div class="restaurent-product-title">
                            <h6 class="mb-2" data-toggle="modal" data-target="#restaurent-popup">
                                <a href="javascript:void(0)"
                                   class="text-light-black fw-600">{{ $product['name'] ?? ''}}</a>
                            </h6>
                            <p class="text-light-white">600-700 Cal.</p>
                        </div>
                        <div class="restaurent-product-label"></div>
                    </div>
                    <div class="restaurent-product-rating"></div>
                </div>
                <div class="restaurent-product-caption-box"><span
                        class="text-light-white">{{ $product['description'] ?? '' }}</span>
                </div>
                <form
                    action="{{ route('app.cart.add-item', ['restaurantId' => $restaurant->id, 'id' => $product['id']]) }}"
                    class="add-to-cart-form" method="post">
                    @csrf
                    <input type="hidden" name="item" value="{{$product['id']}}">
                    @if(isset($product['option_group']))
                        @foreach($product['option_group'] as $optiongroup)
                            @if(isset($optiongroup['options']))
                                <div class="form-group">
                                    <label>{{ $optiongroup['name']  }}</label><br>
                                    <select name="{{$optiongroup['name']}}">
                                        <option value="0" selected>None</option>
                                        @foreach($optiongroup['options'] as $option)
                                            <option
                                                value="{{ $option['id']}}">{{ $option['name'] }}
                                                ${{isset($option['value']) ? number_format($option['value'], 2) : number_format(0, 2)}} </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif
                        @endforeach
                    @endif
                    <div class="form-group">
                        <button type="submit" class="btn btn-success add-to-cart">Add To Cart</button>
                        <span class="text-success fw-600 no-margin">
                            ${{ is_numeric($product['price']) ? number_format($product['price'], 2) : number_format(0, 2)}}</span>
                    </div>
                </form>
                <div
                    class="restaurent-product-price">
                </div>
                <div class="restaurent-tags-price">
                    <div class="restaurent-tags">
                    </div>
                    <span class="circle-tag">
                        <img
                            src="/img/svg/010-heart.svg"
                            alt="tag">
                    </span>
                </div>
            </div>
            <div
                class="restaurent-product-img">
                @if(isset($product['image_url']))
                    <img
                        src="{{ $product['image_url']}}"
                        class="img-fluid"
                        alt="#">
                @endif
            </div>
        </div>
    </div>
</div>
