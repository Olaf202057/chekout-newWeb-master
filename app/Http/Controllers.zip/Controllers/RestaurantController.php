<?php

namespace App\Http\Controllers;

use App\Repositories\Vendors\VendorsRepositoryInterface;
use Illuminate\Http\Request;

class RestaurantController extends Controller
{
    public function index(VendorsRepositoryInterface $vendorsRepository){
        $restaurants = $vendorsRepository->getVendors();
        return $restaurants;
        return view('app.restaurant.index');
    }

    public function showRestaurant(Request $request, VendorsRepositoryInterface $vendorsRepository, $id){
        // Todo: Frontend needs review dates...
        $restaurantData = $vendorsRepository->getVendorById($id);
        // Todo: Will need to fix hours of operation into normal times
        $products = $vendorsRepository->getVendorProducts($id);
        $reviews = $vendorsRepository->getVendorReviews($id);
        $menus = $vendorsRepository->getVendorMenus($id);
        //return $menus;
        $menuInc = 0;
        foreach($menus as $menu){
            $sections = $vendorsRepository->getVendorMenuSections($menu['id']);
            $sectionInc = 0;
            foreach($sections as $section){
                $menu['sections'][$sectionInc] = $section;
                $items = $vendorsRepository->getVendorItemsBySectionId($section['id']);
                $menu['sections'][$sectionInc]['items'] = $items;
                $itemsInc = 0;
                foreach($items as $item){
                    $itemgroups = $vendorsRepository->getOptGroupByItemId($item['id']);
                    $item['option_group'] = $itemgroups;
                    $optgroupInc = 0;
                    foreach($itemgroups as $group){
                        $options = $vendorsRepository->getOptionsByOptgroupId($group['id']);
                        $group['options'] = $options;
                        $item['option_group'][$optgroupInc] = $group;
                        $optgroupInc ++;
                    }

                    $menu['sections'][$sectionInc]['items'][$itemsInc] = $item;
                }
                $sectionInc++;
            }
            $menus[$menuInc] = $menu;
            $menuInc++;
        }
        // Todo: Need to just do a list of products for this menu?
        return view('app.restaurant.show', [
            'restaurant' => $restaurantData,
            'products' => $products,
            'reviews' => $reviews,
            'menus' => $menus
        ]);
    }

    public function selectNew($restaurantId){
        session()->forget('cart');
        return redirect('/restaurant/' . $restaurantId );
    }

    public function goBack($restaurantId){
        return redirect('/restaurant/' . $restaurantId );
    }

    public function showMenuItem(){
        return view('app.restaurant.items.index');
    }
}
