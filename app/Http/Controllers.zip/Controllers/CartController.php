<?php

namespace App\Http\Controllers;

use App\Models\Firebase\Cart;
use App\Repositories\Vendors\VendorsRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use function Symfony\Component\String\s;

class CartController extends Controller
{
    public function addItem(Request $request, $restaurantId, $id, VendorsRepositoryInterface $vendorsRepository)
    {
        // Todo: If they are different vendors do we show an error or create another cart?
        $options = $request->except(['item', '_token']);
        $cart = null;
        $item = $vendorsRepository->getProductById($id);

        return $this->sessionBasedCartFunctions($restaurantId, $item, $options, $vendorsRepository);
    }

    private function parseItemWithOptions($item, $options, $repo)
    {
        $price = str_replace(':', '.', $item->price);
        $optionList = [];
        foreach ($options as $key => $value) {
            $optionObj = $repo->getOptionById($value);
            if($optionObj && $optionObj->value){
                $price = $price + $optionObj->value;
                array_push($optionList, $key . ': ' . $optionObj->name);
            }
        }

        $newItem = [
            'id' => $item->id,
            'name' => $item->name,
            'quantity' => 1,
            'price' => $price,
            'options' => $optionList
        ];
        return $newItem;
    }

    private function sessionBasedCartFunctions($restaurantId, $item, $options, $vendorsRepository){
        if (session()->has('cart')) {
            // Session has cart
            $cart = session('cart');
            if ($this->compareVendors($restaurantId, $cart)) {
                session()->forget('cart');
                $items = $cart->items;
                array_push($items, $this->parseItemWithOptions($item, $options, $vendorsRepository));
                $cart->items = $items;
                $cart->subtotal = 0;
                foreach ($cart->items as $item) {
                    if(isset($item['price']) && is_numeric($item['price'])){
                        $cart->subtotal = $cart->subtotal + (($item['price'] ?? 0) * $item['quantity']);
                    }
                }
                session()->put('cart', $cart);
                return response()->json($cart);
            } else {
                $buttons = '<a class="btn btn-outline-dark mr-2" href="' . route('app.restaurant.select-new', ['restaurantId' => $restaurantId]) . '">Stay Here</a><a class="ml-2 btn btn-outline-dark" href="' . route('app.restaurant.go-back', ['restaurantId' => $cart->vendor ?? 0]) . '">Go Back</a>';
                return response()->json(
                    [
                        'error' => 'You already have items in your cart from another restaurant.',
                        'cart_vendor' => $cart->vendor,
                        'new_vendor' => $restaurantId,
                        'alert' => $buttons
                    ]
                );
            }
        } else {
            $cart = new Cart;
            $cart->vendor = $restaurantId;
            $cart->items = array($this->parseItemWithOptions($item, $options, $vendorsRepository));
            $cart->subtotal = 0;
            foreach ($cart->items as $item) {
                if(isset($item['price']) && is_numeric($item['price'])){
                    $cart->subtotal = $cart->subtotal + (($item['price'] ?? 0) * $item['quantity']);
                }
            }
            session()->put('cart', $cart);
            return response()->json($cart);
        }
    }

    public function removeItem(Request $request)
    {
        if (session()->has('cart')) {
            $cart = session('cart');
            $items = $cart->items;
            if (isset($items[$request->index]) && $items[$request->index]['id'] == $request->item) {
                unset($items[$request->index]);
                $cart->items = $items;
                $cart->subtotal = 0;
                foreach ($cart->items as $item) {
                    $cart->subtotal = $cart->subtotal + ($item['price'] * $item['quantity']);
                }
                session()->forget('cart');
                session()->put('cart', $cart);
                return response()->json($cart);
            }
        }
        return response()->json([
            'error' => 'That item no longer exists in the cart.'
        ]);
    }

    private function compareVendors($restaurantId, $cart)
    {
        // Todo: If not same vendors, return back with a modal for them to select a new vendor or whatever they want'
        if ($restaurantId == $cart->vendor) {
            return true;
        }
        return false;
    }
}
